﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MiCalculadora
{
    public partial class LaCalculadora : Form
    {
        public LaCalculadora()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.InitialComponent();


        }
        /// <summary>
        /// Realiza las 4 operaciones basicas matematicas
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        /// <param name="opeador"></param>
        /// <returns></returns> retorno el resultado en double segun la operacion que se haya realizado
        private double Operar(string num1, string num2, string opeador)
        {
            double resultado;
            Numero numero1 = new Numero(num1);
            Numero numero2 = new Numero(num2);
            resultado = Calculadora.Operar(numero1, numero2, opeador);

            return resultado;
        }

        private void cmbOperador_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// Realiza la operacion solicitada por el usuario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOperar_Click(object sender, EventArgs e)
        {
            string num1 = txtNum1.Text;
            string num2 = txtNum2.Text;
            string operador = cmbOperador.Text;
            double aux;
            string resultado;
            aux = this.Operar(num1, num2, operador);

            resultado = Convert.ToString(aux);
            lblResultado.Text = resultado;

        }
        /// <summary>
        /// Inicializa los text box el combo box y la etiqueta
        /// </summary>
        public void InitialComponent()
        {
            lblResultado.Text = "";
            cmbOperador.Text = "";
            txtNum1.Text = "0";
            txtNum2.Text = "0";

        }
        /// <summary>
        /// Se encarga de Limpiar los text box y el Label
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            this.InitialComponent();
        }

        /// <summary>
        /// convierte el numero decimal ingresado por el usuario a binario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBin_Click(object sender, EventArgs e)
        {
            Numero num = new Numero();
            string aux;
            double num1, num2;
            bool vali, vali2;
            string Nb;
            double resultado;

            if (lblResultado.Text != "")
            {
                if (lblResultado.Text == "No es binario")
                {
                    resultado = Convert.ToDouble(txtNum1.Text) + Convert.ToDouble(txtNum2.Text);
                    lblResultado.Text = num.DecimalBinario(resultado);
                }
                else
                {
                    aux = lblResultado.Text;
                    lblResultado.Text = num.DecimalBinario(aux);
                }


            }
            else
            {
                if (txtNum1.Text != "0" && txtNum2.Text != "0")
                {
                    /* resultado = Convert.ToDouble(txtNum1.Text) + Convert.ToDouble(txtNum2.Text);
                     lblResultado.Text = num.DecimalBinario(resultado);*/
                    vali = double.TryParse(txtNum1.Text, out num1);
                    vali2 = double.TryParse(txtNum2.Text, out num2);

                    if (vali && vali2)
                    {
                        resultado = num1 + num2;
                        Nb = Convert.ToString(resultado);
                        aux = num.DecimalBinario(Nb);
                        MessageBox.Show("Desimal\n 00" + Nb);
                        MessageBox.Show("Binario \n " + aux);
                        lblResultado.Text = aux;
                    }
                    else
                    {
                        MessageBox.Show("Numero invalido");
                    }

                }
                else
                {
                    if (txtNum1.Text == "0")
                    {
                        aux = txtNum2.Text;
                        lblResultado.Text = num.DecimalBinario(aux);
                    }
                    else
                    {
                        aux = txtNum1.Text;
                        lblResultado.Text = num.DecimalBinario(aux);
                    }
                }


            }


        }
        /// <summary>
        /// convierte el numero binario ingresado por el usuario a Decimal
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDes_Click(object sender, EventArgs e)
        {
            Numero num = new Numero();
            string aux;
            bool vali,vali2;
            double num1, num2;
            string Nb;
            double resultado=0;

            if (lblResultado.Text != "")
            {
                aux = lblResultado.Text;
                lblResultado.Text = num.BinarioDecimal(aux);

            }
            else
            {
                if (txtNum1.Text != "0" && txtNum2.Text != "0")
                {

                    vali = double.TryParse(txtNum1.Text, out num1);
                    vali2 = double.TryParse(txtNum2.Text, out num2);

                    if (vali&&vali2)
                    {
                        resultado = num1 + num2;
                        aux = Convert.ToString(resultado);
                        Nb = num.BinarioDecimal(aux);
                        MessageBox.Show("Binario\n 00" + aux);
                        MessageBox.Show("Desimal \n " + Nb);
                        lblResultado.Text = Nb;
                    }
                    else
                    {
                        MessageBox.Show("No es Binario");
                    }

                }
                else
                {
                    if (txtNum1.Text == "0")
                    {
                        aux = txtNum2.Text;
                        lblResultado.Text = num.BinarioDecimal(aux);
                    }
                    else
                    {
                        aux = txtNum1.Text;
                        lblResultado.Text = num.BinarioDecimal(aux);
                    }
                }

            }
        }
        /// <summary>
        /// Cierra la calculadora
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCerar_Click(object sender, EventArgs e)
        {
            LaCalculadora.ActiveForm.Close();
        }
    }
}
