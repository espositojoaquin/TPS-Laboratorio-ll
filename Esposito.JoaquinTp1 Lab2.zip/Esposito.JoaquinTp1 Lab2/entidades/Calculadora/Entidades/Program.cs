﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Entidades
{
    class Program
    {
        static void Main(string[] args)
        {
            Numero num = new Numero();
            string bin = "2";
            double num2 = 2;

            string resultado;
            
            resultado = num.DecimalBinario(num2);

            Console.WriteLine("El numero en binario es: 00{0} ", resultado);
            Console.ReadKey();
            
        }
    }
}
