﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EntidadesInstanciables;
using Excepciones;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        /// <summary>
        /// Verifica si se ingresa un alumno repetido a la universidad.
        /// </summary>
        [TestMethod]
        public void checkAlumnoRepetido()
        {
            try
            {
                Universidad g1 = new Universidad();
                Alumno a1 = new Alumno(1, "Juan", "Lopez", "12234456",
                EntidadesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Programacion, Alumno.EEstadoCuenta.Becado);

                Alumno a2 = new Alumno(2, "Juana", "Martinez", "12234458",
               EntidadesAbstractas.Persona.ENacionalidad.Extranjero, Universidad.EClases.Laboratorio, Alumno.EEstadoCuenta.Deudor);
                g1 += a1;
                g1 += a2;
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(AlumnoRepetidoException));
            }
        }
        /// <summary>
        /// Verifica que la longitud del DNI con respecto a la nacionalidad sea válido.
        /// </summary>
        [TestMethod]
        public void checkLongitudDni()
        {
            try
            {
                Alumno a2 = new Alumno(2, "Carlos", "Gonzales", "899999999", EntidadesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio, Alumno.EEstadoCuenta.AlDia);
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(NacionalidadInvalidaException));
            }
        }
        /// <summary>
        /// Verifica que el DNI ingresado sea válido.
        /// </summary>
        [TestMethod]
        public void checkNumeroDniIvalidoArg()
        {
            try
            {
                Alumno a2 = new Alumno(6, "Juan", "Perez", "1223asd4656",  EntidadesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio,Alumno.EEstadoCuenta.Deudor);
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(DniIvalidoException));
            }
        }
        /// <summary>
        /// Verifica que el DNI ingresado con respecto a la nacionalidad sea válido
        /// </summary>
        [TestMethod]
        public void checkNumeroDniIvalidoExt()
        {     
            try
            {
                Alumno a2 = new Alumno(7, "Joaquin", "Suarez", "911224", EntidadesAbstractas.Persona.ENacionalidad.Extranjero, Universidad.EClases.Laboratorio, Alumno.EEstadoCuenta.AlDia);
            }
            catch (NacionalidadInvalidaException e)
            {
                Assert.IsInstanceOfType(e, typeof(NacionalidadInvalidaException));
            }
        }
        /// <summary>
        /// Verifica que el valor ingresado es incorrecto
        /// </summary>
        [TestMethod]
        public void checkNombreApellido()
        {
            string valorErroneo = " ";
            Alumno a2 = new Alumno(8, "Rodrigo", "Sm4ith", "22236456",EntidadesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Legislacion,
           Alumno.EEstadoCuenta.AlDia);
            Assert.AreEqual(valorErroneo, a2.Apellido);
        }
        /// <summary>
        /// Verifica que no haya valores nulos
        /// </summary>
        [TestMethod]
        public void checkValoresNulos()
        {
            Profesor i1 = new Profesor(2, "Roberto", "Juarez", "32234456", EntidadesAbstractas.Persona.ENacionalidad.Argentino);
            Jornada j1 = new Jornada(Universidad.EClases.Legislacion,i1);
            Assert.IsNotNull(j1.Alumnos);
        }
        /// <summary>
        /// Verifica si hay valores nulos en la instancia dada.
        /// </summary>
        [TestMethod]
        public void checkValoresNulos2()
        {
            Profesor i1 = new Profesor(1, "Juan", "Lopez", "12234456",EntidadesAbstractas.Persona.ENacionalidad.Argentino);
            Jornada j1 = new Jornada(Universidad.EClases.Legislacion, i1);
            j1.Alumnos = null;
            Assert.IsNull(j1.Alumnos);
        }
    }
}
